/* mightygumball.js */
/*
 * JSON 파일의 내용을 JSONP로 가져옴
 * 3초마다 업데이트 됨
 *
 */

// var lastReportTime 

window.onload = init;
//추가1
function init() {
	//handleRefresh();
}

function handleRefresh() {
	
	//updateSales 
}
//추가2
function updateSales(sales) {
	
	//div.innerHTML 
}


